package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int firstNum;
    private String operation;
    private StringBuilder history = new StringBuilder();
    private TextView screen, historyScreen;
    private ScrollView historyScroll;
    private boolean isNewOp = true; // To clear input on new number entry

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing UI Components
        screen = findViewById(R.id.screen);
        historyScreen = findViewById(R.id.historyScreen);
        historyScroll = findViewById(R.id.historyScroll);

        Button ac = findViewById(R.id.ac);
        Button del = findViewById(R.id.del);
        Button div = findViewById(R.id.div);
        Button times = findViewById(R.id.times);
        Button min = findViewById(R.id.min);
        Button plus = findViewById(R.id.plus);
        Button equal = findViewById(R.id.equal);
        Button point = findViewById(R.id.point);
        Button num0 = findViewById(R.id.num0);
        Button num1 = findViewById(R.id.num1);
        Button num2 = findViewById(R.id.num2);
        Button num3 = findViewById(R.id.num3);
        Button num4 = findViewById(R.id.num4);
        Button num5 = findViewById(R.id.num5);
        Button num6 = findViewById(R.id.num6);
        Button num7 = findViewById(R.id.num7);
        Button num8 = findViewById(R.id.num8);
        Button num9 = findViewById(R.id.num9);

        // Number Buttons Click Listener
        View.OnClickListener numberClickListener = view -> {
            Button clicked = (Button) view;
            if (isNewOp) {
                screen.setText(clicked.getText());
                isNewOp = false;
            } else {
                screen.append(clicked.getText().toString());
            }
        };

        num0.setOnClickListener(numberClickListener);
        num1.setOnClickListener(numberClickListener);
        num2.setOnClickListener(numberClickListener);
        num3.setOnClickListener(numberClickListener);
        num4.setOnClickListener(numberClickListener);
        num5.setOnClickListener(numberClickListener);
        num6.setOnClickListener(numberClickListener);
        num7.setOnClickListener(numberClickListener);
        num8.setOnClickListener(numberClickListener);
        num9.setOnClickListener(numberClickListener);
        point.setOnClickListener(numberClickListener);

        // Operator Buttons Click Listener
        View.OnClickListener operatorClickListener = view -> {
            Button clicked = (Button) view;
            firstNum = Integer.parseInt(screen.getText().toString());
            operation = clicked.getText().toString();
            isNewOp = true;
        };

        div.setOnClickListener(operatorClickListener);
        times.setOnClickListener(operatorClickListener);
        plus.setOnClickListener(operatorClickListener);
        min.setOnClickListener(operatorClickListener);

        // Clear Button (AC)
        ac.setOnClickListener(view -> {
            screen.setText("0");
            history.setLength(0);
            historyScreen.setText("");
            firstNum = 0;
            isNewOp = true;
        });

        // Delete Button (DEL)
        del.setOnClickListener(view -> {
            String text = screen.getText().toString();
            if (text.length() > 1) {
                screen.setText(text.substring(0, text.length() - 1));
            } else {
                screen.setText("0");
                isNewOp = true;
            }
        });

        // Equal Button (Calculate result and update history)
        equal.setOnClickListener(view -> {
            int secondNum = Integer.parseInt(screen.getText().toString());
            int result = 0;

            switch (operation) {
                case "/":
                    if (secondNum == 0) {
                        screen.setText("Error");
                        return;
                    }
                    result = firstNum / secondNum;
                    break;
                case "X":
                    result = firstNum * secondNum;
                    break;
                case "+":
                    result = firstNum + secondNum;
                    break;
                case "-":
                    result = firstNum - secondNum;
                    break;
            }

            screen.setText(String.valueOf(result));

            // Add calculation to history
            history.append(firstNum).append(" ").append(operation).append(" ")
                    .append(secondNum).append(" = ").append(result).append("\n");
            historyScreen.setText(history.toString());

            // Scroll to bottom
            historyScroll.post(() -> historyScroll.fullScroll(View.FOCUS_DOWN));

            firstNum = result;
            isNewOp = true;
        });
    }
}
